
function temperatura(a){ 
    let temp = (a-32)*(5/9)
    alert("La temperatura calculada es " + temp + "°C");
}



